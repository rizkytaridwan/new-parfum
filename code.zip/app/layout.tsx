import type React from "react"
import type { Metadata } from "next"
import { PT_Serif as Geist_Serif, Geist } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import "./globals.css"

const geistSerif = Geist_Serif({ subsets: ["latin"], weight: ["400", "500", "700"] })
const geistSans = Geist({ subsets: ["latin"], weight: ["400", "500", "600", "700"] })

export const metadata: Metadata = {
  title: "Parfum Premium - Koleksi Wangi Terbaik Indonesia",
  description:
    "Jelajahi koleksi parfum premium dari brand internasional terkemuka. Dapatkan wangi eksklusif dengan harga kompetitif dan kualitas terjamin.",
  keywords: "parfum, wangi, brand internasional, parfum pria, parfum wanita, koleksi wangi",
  applicationName: "Parfum Store",
  authors: [{ name: "Parfum Premium" }],
  creator: "Parfum Premium",
  publisher: "Parfum Premium",
  robots: "index, follow",
  openGraph: {
    type: "website",
    locale: "id_ID",
    url: "https://yoursite.com",
    siteName: "Parfum Premium",
    title: "Parfum Premium - Koleksi Wangi Terbaik",
    description: "Jelajahi koleksi parfum premium dengan berbagai pilihan aroma.",
    images: [
      {
        url: "https://yoursite.com/og-image.png",
        width: 1200,
        height: 630,
        alt: "Parfum Premium",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Parfum Premium",
    description: "Koleksi wangi terbaik",
  },
  viewport: {
    width: "device-width",
    initialScale: 1,
    maximumScale: 5,
  },
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="id">
      <head>
        <meta charSet="utf-8" />
        <link rel="canonical" href="https://yoursite.com" />
        <link rel="sitemap" type="application/xml" href="/sitemap.xml" />
        <link rel="alternate" hrefLang="id" href="https://yoursite.com" />
        {/* Google Site Verification & AdSense */}
        <meta name="google-site-verification" content="YOUR_GOOGLE_VERIFICATION_CODE" />
        <meta name="google-adsense-account" content="ca-pub-YOUR_ADSENSE_ID" />
      </head>
      <body className={`${geistSans.className} bg-background text-foreground antialiased`}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
